//connect is built on the top of http module
//conect is a middleware
//we can create middleware using connect 3rd party modules and place it in HTTP Pipeline
//to intercept the HTTP Request and HTTP Response
const connect = require('connect');

var app = connect();

//http://localhost:3000/err
app.use('/err', (req, res, next) => {
    //Handing Exception in middleware
    try {
        throw 'Some Error Occured';
    } catch (error) {
        //Passing arguments in the next() will invoke the middleware with 4 args
        next({ middleware: 'err', errorDetails: error });
    }
});

//http://localhost:3000/admin
app.use('/admin', (req, res, next) => {
    console.log('Admin Logger');
    next();
});

//http://localhost:3000/admin
app.use('/admin', (req, res, next) => {
    try {
        res.write('<h1>Welcome to Admin Page</h1>');
        res.end();
    } catch (error) {
        next({ middlware: 'admin', errorDetails: error });
    }

});

//http://localhost:3000/
app.use('/', (req, res, next) => {
    console.log('Home Logger');
    next();
});

//http://localhost:3000/
app.use('/', (req, res, next) => {
    res.write('<h1>Welcome to Home Page</h1>');
    res.end();
});

//Creating middleware which needs to be executed for error
//Error handling middleware need to be placed at the last in HTTP Pipeline
//First arguments will get the error details which is passed in the next()
app.use((err, req, res, next) => {
    console.log(err);
    res.end(`<h1>Error occured in ${err.middleware} : ${err.errorDetails} </h1>`);
});

app.listen(3000, () => {
    console.log('Server started at localhost 3000. Press CTRL + C to stop the server');
});
