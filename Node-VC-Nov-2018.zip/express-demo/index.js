//express is built on the top of connect
const path = require('path');
const express = require('express');

//body-parser is a 3rd party middleware which is used to parse the request body
const bodyParser = require('body-parser');

var app = express();

//creating Routes using Express Router
var root = express.Router();
var admin = express.Router();

app.set('view engine', 'pug');
app.set('views', path.join(__dirname, 'views'));

//To parse the data into JS object, if the content-type is application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: false }));//extended:true supports nested objects as well

//To parse the data into JS object, if the content-type is application/json 
app.use(bodyParser.json());

app.use('/', root);
app.use('/admin', admin);

//POST : http://localhost:3000/admin/person
//Post the person details in the request body
admin.post('/person', (req, res, next) => {
    //To access the data posted in req.body
    console.log(req.body);
    var personObj = req.body;
    //converting javascript object to json and send in response
    res.json(personObj);
});


//GET : http://localhost:3000/admin/person/superadmin/chennai
admin.get('/person/:role/:city', (req, res, next) => {
    //To access the path parameter /:role passed in the URL
    var role = req.params['role'];
    //To access the path parameter /:city passed in the URL
    var city = req.params['city'];
    res.send(`<h1>Person Role : ${role} City: ${city}</h1>`);
});

//GET : http://localhost:3000/admin/person?name=Karthik&city=Bangalore
admin.get('/person', (req, res, next) => {
    //To access the query string passed in the URL
    var query = req.query; //{name:'Karthik',city:'Bangalore'}
    res.send(`<h1>Person Details Name : ${query.name} City: ${query.city}</h1>`);
});


//GET : http://localhost:3000/admin/err/
admin.get('/err', (req, res, next) => {
    try {
        throw 'error occured';
    } catch (error) {
        next({ route: 'admin', endPoint: 'err', errorDetails: error });
    }
});

//GET : http://localhost:3000/admin/
admin.get('/', (req, res, next) => {
    res.send('<h1>Welcome to Admin Page</h1>');
});

//GET : http://localhost:3000/
root.get('/', (req, res, next) => {
    //Rendering the pug template resides in the view folder
    res.render('index', { title: 'Express',locations:['Bangalore','Chennai','Mumbai','Pune'] });
});

//POST : http://localhost:3000/
root.post('/', (req, res, next) => {
    res.send('<h1>HTTP-POST</h1>');
});

//PUT : http://localhost:3000/
root.put('/', (req, res, next) => {
    res.send('<h1>HTTP-PUT</h1>');
});

//DELETE : http://localhost:3000/
root.delete('/', (req, res, next) => {
    res.send('<h1>HTTP-DELETE</h1>');
});

app.use((err, req, res, next) => {
    res.send(`<h1>Exception Handled from route: ${err.route} endpoint: ${err.endPoint} Error: ${err.errorDetails}</h1>`);
});

app.listen(3000, () => {
    console.log('Server started at localhost 3000. Press CTRL + C to stop the server');
});

//Jade Templating Syntax : https://naltatis.github.io/jade-syntax-docs/