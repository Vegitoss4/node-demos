const express = require('express');
const mongoose = require('mongoose');

var app = express();
var root = express.Router();
var api = express.Router();

var uri = 'mongodb://localhost/SampleDB';

mongoose.connect(uri, { useNewUrlParser: true }).then(() => {
    var connection = mongoose.connection;
    var locations = [];
    var Location = mongoose.model('Location', { _id: Number, location: String }, 'locations');

    app.use('/', root);
    app.use('/api/locations', api);

    api.get('/', (req, res, next) => {
        Location.find((err, docs) => {
            if (err) {
                next(err);
            } else {
                docs.forEach((doc) => {
                    locations.push(doc);
                });
                res.status(200).json(locations);
            }
        });
    });

    root.get('/', (req, res, next) => {
        res.send('Location RESTFul Services');
    });

    app.use((err, req, res, next) => {
        console.log(err);
        next();
    });

}).catch((err) => {
    console.log(err);
});

app.listen(3000, () => {
    console.log('Server Started');
});