var addNumbers = function(a,b){
    return a + b;
}
//To invoke this function
var addResult = addNumbers(5,6);
console.log(addResult);

console.log(typeof(addNumbers));//function
