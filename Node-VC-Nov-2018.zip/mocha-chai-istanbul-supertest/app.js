const express = require('express');
const app = express();

//GET : http://localhost:3000
app.get('/',(req,res,next)=>{
    res.send('<h1>Welcome to Node Unit Testing</h1>');
});

//POST : http://localhost:3000
app.post('/',(req,res,next)=>{
    res.json({name:'Karthik'});
});

module.exports = app;