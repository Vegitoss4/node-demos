const app = require('./app');

app.listen(3000,()=>{
    console.log('Server Started at locahost 3000');
});