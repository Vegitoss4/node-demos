const app = require('./helpers/app');

const should = require('chai').should();

//HTTP Assertions without opening the browser
const supertest = require('supertest');

describe('Test Suite contains test cases for my trainees to understand Mocha, chai and supertest', () => {

    it('should add 1 plus 1 synchronously', () => {
        var onePlusOne = 1 + 1;
        onePlusOne.should.equal(2);
    });

    it('should add 1 plus 1 asynchronously', (done) => {
        //we can test the asynchronous method
        var onePlusOne = 1 + 1;
        onePlusOne.should.equal(2);
        done(); //it wont jump to the next test case
    });

    it('number,string, object', (done) => {
        var name = 'Karthik';
        var age = 30;
        var foo = { fooVar: 'Foo Variable' };
        name.should.be.a('string');
        name.should.have.length(7);
        age.should.be.below(40);
        age.should.be.within(25, 35);
        foo.should.be.an('object');
        foo.should.have.property('fooVar');
        done();
    });

    it('regular expression', (done) => {
        var pincode = 560066;
        pincode.should.match(/^\d{6}$/);
        done();
    });


    it('exceptions', (done) => {
        var errFn = () => {
            throw new Error('Custom Error');
        }
        errFn.should.throw(Error);
        errFn.should.throw(Error, /Custom Error/);
        done();
    });

    it('should access home page', (done) => {
        supertest(app).get('/').expect(200, done);

    });

    it('should send a json response', (done) => {
        supertest(app).post('/').expect('Content-Type', 'application/json; charset=utf-8', done);

    });

    it('should send a json response with the object with property name with the value karthik', (done) => {
        supertest(app).post('/').expect({ name: 'Karthik' }, done);
    });

    it('should return 404', (done) => {
        supertest(app).post('/notfound').expect(404, done);
    });
});