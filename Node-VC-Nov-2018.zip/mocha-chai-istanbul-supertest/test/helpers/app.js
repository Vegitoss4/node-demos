const app = require('../../app');

//Additional Features can be added for for testing purpose without affecting the oringinal one
module.exports = app;