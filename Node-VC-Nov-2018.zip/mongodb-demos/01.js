//MongoDB official npm package to connect MongoDB from Node.js
const mongodb = require('mongodb');

//Returns the MongoClient Class
var MongoClient = mongodb.MongoClient;

//URI to connect MongoDB
var uri = 'mongodb://localhost/SampleDB';

//Connecting MongoDB Server
MongoClient.connect(uri,{ useNewUrlParser: true },(err,db)=>{
    if(err){
        console.log(err);
        return;
    }
    console.log(`Connected to Database : SampleDB`);
    db.close();
    console.log(`Connection closed`);
});

