const http = require('http');

//request : Readable Stream
//response : Writable Stream
var cws = http.createServer( (request, response)=> {
    console.log(request.socket.remoteAddress);//To get the request address
    if (request.url == '/home') {
        response.write('<h1>Welcome to Capgemini Web Server</h1>');
        response.end();
    } else {
        response.setHeader('Content-Type', 'text/plain');
        response.write('<h1>Welcome to Node.js Web Developement</h1>');
        response.end();
    }
});

cws.listen(3000, function () {
    console.log('Server Started and listening on localhost at port 3000');
});

/*
var addNumbers = function (a, b) {
    console.log(`Adding ${a} and ${b}`);
    return a + b;
}

//var add = (a, b) => a + b;

//Arrow Functions 
var add = (a, b) => {
    console.log(`Adding ${a} and ${b}`);
    return a + b;
}
*/

/*var Test = function(){
    //All JS functions will return the current instance by default
    this.id =0;
    this.name = '';
    //return this;
}
console.log(new Test());*/

//usage of bind()
/*(function(){
    this.counter = 0;
    setInterval(function(){
        console.log(this.counter++);
    }.bind(this),1000);
})();*/

//no need to use bind() beacuse by default arrow function are binded with the parent instance
/*(()=>{
    this.counter = 0;
    setInterval(()=>{
        console.log(this.counter++);
    },1000);
})();*/


