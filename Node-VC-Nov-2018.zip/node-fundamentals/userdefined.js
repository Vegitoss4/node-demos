var Calculator = require('./calculator');

var calcObj = new Calculator();
console.log(calcObj.add(5,6));
console.log(calcObj.multiply(5,6));


/*
Inbuilt Modules
User defined Modules
Third party modules

	npmjs.com
	npm -> node package manager

	Syntax:
	npm install <Switch> <PackageName>@<Version>

	npm install -S bootstrap@3.3.7


	Global Module : npm install -g <packageName> : It can be used by any project in that system

	npm install -g rimraf

	Project Module : It can be used only by that project

	To create Package.json
	--------------------
	
	npm init -y

	Project Save Dependency : npm install -S <Package Name> (In both Dev & Prod)
	npm install -S connect
	
	Project Developer Dependency : npm install -D <Package Name> (In Dev)
	npm install -D chai 

	npm install : it will install all the packages specified in package.json
	

To set proxy
-----------
npm config set http-proxy http://blrproxy.igate.com:8080

npm config set https-proxy http://blrproxy.igate.com:8080


Symbols:

version : Exact version

>version : Latest Version

~version : Approximately equivalent version("connect": "~3.6.6") will match all version 3.3.x

^version : Compatible with version("connect": "^3.6.6") will match all version 3.x.x





*/