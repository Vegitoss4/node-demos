var Calculator = require('./sut/calculator');
var calcObj = new Calculator();
console.log(calcObj.add(5,6));
console.log(calcObj.multiply(5,6));
