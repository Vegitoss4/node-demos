var Calculator = require('../sut/calculator');

//In chai we have 2 BDD Style Assertions
var should = require('chai').should();
var expect = require('chai').expect;

describe('Testing the Calculator class',()=>{
    var calcObj;

    //Executes before all the test cases only once
    before(()=>{
        calcObj = new Calculator();
    });

    //should based assertion
    it('should add two numbers',()=>{
        var actualResult = calcObj.add(5,2);
        var expectedResult = 7;
        expectedResult.should.equal(actualResult);
    });

    //expect based assertion
    it('should multiply two numbers',()=>{
        var actualResult = calcObj.multiply(5,2);
        var expectedResult = 10;
        expect(expectedResult).to.equal(actualResult);
    });

    //Executes after all the test cases only once
    after(()=>{
        calcObj = null;
    });
   
});